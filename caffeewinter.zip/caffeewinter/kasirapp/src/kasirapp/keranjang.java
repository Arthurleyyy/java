/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package kasirapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Sebastian
 */
public class keranjang extends javax.swing.JFrame {
    
    private static final Logger logger = Logger.getLogger(keranjang.class.getName());
    private String idSesi;
    private datamenu parentForm;
    private Connection conn;
    private DefaultTableModel modelKeranjang;
    private DefaultTableModel modelStruk;

    /**
     * Creates new form keranjang
     */
    public keranjang(String idSesi, datamenu parentForm, Connection conn) {
        this.idSesi = idSesi;
        this.parentForm = parentForm;
        this.conn = conn;
        initComponents();
        initializeModels();
        if (conn != null) {
            populateTable();
            logger.info("Koneksi database berhasil, id_sesi: " + idSesi);
        } else {
            logger.severe("Koneksi database gagal saat inisialisasi!");
            JOptionPane.showMessageDialog(this, "Koneksi database gagal! Tidak dapat memuat keranjang.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
        setLocationRelativeTo(null);
    }

    private void initializeModels() {
        modelKeranjang = new DefaultTableModel(new String[]{"Nama", "Harga", "ID Pesanan"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        listmenuyangmaudibayar.setModel(modelKeranjang);
        modelStruk = new DefaultTableModel(new String[]{"Detail"}, 0);
        strukbonpembelian.setModel(modelStruk);
        strukbonpembelian.setRowHeight(20);
        strukbonpembelian.getColumnModel().getColumn(0).setPreferredWidth(200);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(230, 200));
    }

    private void populateTable() {
        modelKeranjang.setRowCount(0);
        int totalPrice = 0;

        if (conn != null) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "SELECT m.nama_menu, p.jumlah, p.subtotal, p.id_pesanan " +
                    "FROM pesanan p JOIN menu m ON p.id_menu = m.id_menu " +
                    "WHERE p.id_sesi = ?")) {
                stmt.setString(1, idSesi);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    String namaMenu = rs.getString("nama_menu") + " (" + rs.getInt("jumlah") + ")";
                    int subtotal = rs.getInt("subtotal");
                    int idPesanan = rs.getInt("id_pesanan");
                    modelKeranjang.addRow(new Object[]{namaMenu, String.format("Rp %,d", subtotal), idPesanan});
                    totalPrice += subtotal;
                }
                if (totalPrice > 0) {
                    modelKeranjang.addRow(new Object[]{"TOTAL", String.format("Rp %,d", totalPrice), null});
                }
            } catch (SQLException ex) {
                logger.severe("Gagal mengisi tabel: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "Gagal mengisi tabel keranjang: " + ex.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            logger.severe("Koneksi database null saat populateTable!");
        }
    }

    private void deleteSelectedItem() {
        int selectedRow = listmenuyangmaudibayar.getSelectedRow();
        logger.info("Tombol HAPUS ditekan, baris terpilih: " + selectedRow);
        if (selectedRow < 0 || selectedRow >= modelKeranjang.getRowCount() || selectedRow == modelKeranjang.getRowCount() - 1) {
            JOptionPane.showMessageDialog(this, "Pilih item yang ingin dihapus (kecuali TOTAL)!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object idPesananObj = modelKeranjang.getValueAt(selectedRow, 2);
        if (idPesananObj == null) {
            logger.severe("id_pesanan null untuk baris " + selectedRow);
            JOptionPane.showMessageDialog(this, "Gagal menghapus: ID pesanan tidak valid!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idPesanan;
        try {
            idPesanan = (Integer) idPesananObj;
            logger.info("ID pesanan untuk dihapus: " + idPesanan);
        } catch (ClassCastException ex) {
            logger.severe("Gagal konversi id_pesanan ke Integer: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "Gagal menghapus: Format ID pesanan salah!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (conn != null) {
            try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM pesanan WHERE id_pesanan = ?")) {
                stmt.setInt(1, idPesanan);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    logger.info("Item dengan id_pesanan " + idPesanan + " berhasil dihapus.");
                    modelKeranjang.removeRow(selectedRow);
                    populateTable();
                    JOptionPane.showMessageDialog(this, "Item berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    logger.severe("Tidak ada baris yang terhapus untuk id_pesanan " + idPesanan);
                    JOptionPane.showMessageDialog(this, "Gagal menghapus: Item tidak ditemukan!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                logger.severe("Gagal menghapus item: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "Gagal menghapus item: " + ex.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            logger.severe("Koneksi database null saat deleteSelectedItem!");
            JOptionPane.showMessageDialog(this, "Koneksi database gagal!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generateReceipt() {
        modelStruk.setRowCount(0);
        int totalPrice = 0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String currentDate = dateFormat.format(new Date());

        modelStruk.addRow(new Object[]{"Tanggal: " + currentDate});
        modelStruk.addRow(new Object[]{"Caffée Winter"});
        modelStruk.addRow(new Object[]{"------------------------------"});
        modelStruk.addRow(new Object[]{"ID    Item         Jumlah    Harga"});

        if (conn != null) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "SELECT m.id_menu, m.nama_menu, p.jumlah, p.subtotal " +
                    "FROM pesanan p JOIN menu m ON p.id_menu = m.id_menu " +
                    "WHERE p.id_sesi = ?")) {
                stmt.setString(1, idSesi);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    int idMenu = rs.getInt("id_menu");
                    String namaMenu = rs.getString("nama_menu");
                    int jumlah = rs.getInt("jumlah");
                    int subtotal = rs.getInt("subtotal");
                    String formattedRow = String.format("%-5d %-12s %-8d %8d", idMenu, namaMenu, jumlah, subtotal);
                    modelStruk.addRow(new Object[]{formattedRow});
                    totalPrice += subtotal;
                }
                if (totalPrice > 0) {
                    modelStruk.addRow(new Object[]{"------------------------------"});
                    modelStruk.addRow(new Object[]{"Total: " + String.format("%,d", totalPrice)});
                    modelStruk.addRow(new Object[]{"------------------------------"});
                    modelStruk.addRow(new Object[]{"Terima Kasih Sudah Jajan"});
                } else {
                    logger.warning("Tidak ada data pesanan untuk id_sesi: " + idSesi);
                    modelStruk.addRow(new Object[]{"Tidak ada pesanan untuk ditampilkan."});
                }
            } catch (SQLException ex) {
                logger.severe("Gagal menghasilkan struk: " + ex.getMessage());
                JOptionPane.showMessageDialog(this, "Gagal menghasilkan struk: " + ex.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            logger.severe("Koneksi database null saat generateReceipt!");
            JOptionPane.showMessageDialog(this, "Koneksi database gagal!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method baru untuk menyimpan transaksi ke database
    private boolean saveTransactionToDatabase() {
        if (conn == null) {
            logger.severe("Koneksi database null saat saveTransactionToDatabase!");
            return false;
        }

        try {
            // Mulai transaksi database
            conn.setAutoCommit(false);
            
            // Hitung total harga
            int totalHarga = 0;
            try (PreparedStatement stmtTotal = conn.prepareStatement(
                    "SELECT SUM(subtotal) as total FROM pesanan WHERE id_sesi = ?")) {
                stmtTotal.setString(1, idSesi);
                ResultSet rsTotal = stmtTotal.executeQuery();
                if (rsTotal.next()) {
                    totalHarga = rsTotal.getInt("total");
                }
            }

            if (totalHarga <= 0) {
                logger.warning("Total harga 0 atau negatif untuk id_sesi: " + idSesi);
                conn.rollback();
                return false;
            }

            // Simpan ke tabel transaksi
            int idTransaksi = 0;
            try (PreparedStatement stmtTransaksi = conn.prepareStatement(
                    "INSERT INTO transaksi (id_sesi, total_harga, status) VALUES (?, ?, 'selesai')", 
                    Statement.RETURN_GENERATED_KEYS)) {
                stmtTransaksi.setString(1, idSesi);
                stmtTransaksi.setInt(2, totalHarga);
                stmtTransaksi.executeUpdate();
                
                ResultSet generatedKeys = stmtTransaksi.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idTransaksi = generatedKeys.getInt(1);
                    logger.info("ID transaksi yang dibuat: " + idTransaksi);
                } else {
                    throw new SQLException("Gagal mendapatkan ID transaksi yang dibuat");
                }
            }

            // Simpan detail transaksi dari tabel pesanan
            try (PreparedStatement stmtDetail = conn.prepareStatement(
                    "INSERT INTO detail_transaksi (id_transaksi, id_menu, nama_menu, harga_satuan, jumlah, subtotal) " +
                    "SELECT ?, p.id_menu, m.nama_menu, m.harga, p.jumlah, p.subtotal " +
                    "FROM pesanan p JOIN menu m ON p.id_menu = m.id_menu " +
                    "WHERE p.id_sesi = ?")) {
                stmtDetail.setInt(1, idTransaksi);
                stmtDetail.setString(2, idSesi);
                int detailRows = stmtDetail.executeUpdate();
                logger.info("Jumlah detail transaksi yang disimpan: " + detailRows);
            }

            // Hapus data dari tabel pesanan setelah berhasil disimpan
            try (PreparedStatement stmtDelete = conn.prepareStatement("DELETE FROM pesanan WHERE id_sesi = ?")) {
                stmtDelete.setString(1, idSesi);
                int deletedRows = stmtDelete.executeUpdate();
                logger.info("Jumlah pesanan yang dihapus: " + deletedRows);
            }

            // Commit transaksi
            conn.commit();
            conn.setAutoCommit(true);
            
            logger.info("Transaksi berhasil disimpan dengan ID: " + idTransaksi);
            return true;
            
        } catch (SQLException ex) {
            try {
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException rollbackEx) {
                logger.severe("Gagal rollback: " + rollbackEx.getMessage());
            }
            logger.severe("Gagal menyimpan transaksi: " + ex.getMessage());
            return false;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        juduldatamenu = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        strukbonpembelian = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        listmenuyangmaudibayar = new javax.swing.JTable();
        jkembali = new javax.swing.JButton();
        jbayar = new javax.swing.JButton();
        jhapus = new javax.swing.JButton();
        gambargarisgaris = new javax.swing.JLabel();
        gambarjudulkeranjang = new javax.swing.JLabel();
        gambarkeranjang = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        juduldatamenu.setFont(new java.awt.Font("Sitka Banner", 3, 36)); // NOI18N
        juduldatamenu.setText("caffee Winter");
        getContentPane().add(juduldatamenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 40, -1, -1));

        strukbonpembelian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(strukbonpembelian);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 170, 260, 420));

        listmenuyangmaudibayar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Nama", "Harga"
            }
        ));
        jScrollPane1.setViewportView(listmenuyangmaudibayar);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 380, -1));

        jkembali.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasirapp.gambar/button_kembali.png.png"))); // NOI18N
        jkembali.setText("KEMBALI");
        jkembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jkembaliActionPerformed(evt);
            }
        });
        getContentPane().add(jkembali, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 540, 130, 40));

        jbayar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasirapp.gambar/button_bayar.png.png"))); // NOI18N
        jbayar.setText("BAYAR");
        jbayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbayarActionPerformed(evt);
            }
        });
        getContentPane().add(jbayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 490, 130, 40));

        jhapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasirapp.gambar/button_hapus.png.png"))); // NOI18N
        jhapus.setText("HAPUS");
        jhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jhapusActionPerformed(evt);
            }
        });
        getContentPane().add(jhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 440, 130, 40));

        gambargarisgaris.setText("---------------------------------------------------------");
        getContentPane().add(gambargarisgaris, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, 300, 10));

        gambarjudulkeranjang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasirapp.gambar/gamabarjudulkeranajang.png"))); // NOI18N
        getContentPane().add(gambarjudulkeranjang, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, 280, 40));

        gambarkeranjang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kasirapp.gambar/gambarkeranjang.jpg"))); // NOI18N
        gambarkeranjang.setText("jLabel1");
        getContentPane().add(gambarkeranjang, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 630));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jkembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jkembaliActionPerformed
    parentForm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jkembaliActionPerformed

    private void jbayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbayarActionPerformed
    generateReceipt();
        generateReceipt();
        
        // Simpan transaksi ke database
        boolean berhasil = saveTransactionToDatabase();
        
        if (berhasil) {
            JOptionPane.showMessageDialog(this, 
                "Pembayaran berhasil! Transaksi telah disimpan.\nStruk tersedia di sisi kanan.", 
                "Sukses", JOptionPane.INFORMATION_MESSAGE);
            
            // Refresh tabel keranjang (akan kosong karena sudah dipindahkan ke transaksi)
            modelKeranjang.setRowCount(0);
            populateTable();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Gagal menyimpan transaksi ke database!", 
                "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
                                                                         
    }//GEN-LAST:event_jbayarActionPerformed

    private void jhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jhapusActionPerformed
         deleteSelectedItem();    // TODO add your handling code here:
    }//GEN-LAST:event_jhapusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
    try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.severe(ex.getMessage());
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel gambargarisgaris;
    private javax.swing.JLabel gambarjudulkeranjang;
    private javax.swing.JLabel gambarkeranjang;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbayar;
    private javax.swing.JButton jhapus;
    private javax.swing.JButton jkembali;
    private javax.swing.JLabel juduldatamenu;
    private javax.swing.JTable listmenuyangmaudibayar;
    private javax.swing.JTable strukbonpembelian;
    // End of variables declaration//GEN-END:variables
}
